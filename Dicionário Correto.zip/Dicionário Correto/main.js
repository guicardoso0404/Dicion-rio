document.getElementById('mostrarDiv').addEventListener('click', function() {
    let minhaDiv = document.getElementById('minhaDiv11');

    if (minhaDiv.style.display === 'none') {
        minhaDiv.style.display = 'block';
    } 
    else {
        minhaDiv.style.display = 'none';
    }
    });
document.getElementById('mostrarDiv2').addEventListener('click', function() {
    let minhaDiv = document.getElementById('minhaDiv12');

    if (minhaDiv.style.display === 'none') {
        minhaDiv.style.display = 'block';
    } 
    else {
        minhaDiv.style.display = 'none';
    }
    });
document.getElementById('mostrarDiv3').addEventListener('click', function() {
    let minhaDiv = document.getElementById('minhaDiv13');

    if (minhaDiv.style.display === 'none') {
        minhaDiv.style.display = 'block';
    } 
    else {
        minhaDiv.style.display = 'none';
    }
    });
document.getElementById('mostrarDiv4').addEventListener('click', function() {
    let minhaDiv = document.getElementById('minhaDiv14');

    if (minhaDiv.style.display === 'none') {
        minhaDiv.style.display = 'block';
    } 
    else {
        minhaDiv.style.display = 'none';
    }
});
document.getElementById('mostrarDiv5').addEventListener('click', function() {
    let minhaDiv = document.getElementById('minhaDiv15');

    if (minhaDiv.style.display === 'none') {
    minhaDiv.style.display = 'block';
    } 
    else {
    minhaDiv.style.display = 'none';
    }
});
document.getElementById('mostrarDiv6').addEventListener('click', function() {
    let minhaDiv = document.getElementById('minhaDiv16');

    if (minhaDiv.style.display === 'none') {
        minhaDiv.style.display = 'block';
    } 
    else {
        minhaDiv.style.display = 'none';
    }
    });
document.getElementById('mostrarDiv7').addEventListener('click', function() {
    let minhaDiv = document.getElementById('minhaDiv17');

    if (minhaDiv.style.display === 'none') {
        minhaDiv.style.display = 'block';
    } 
    else {
        minhaDiv.style.display = 'none';
    }
});
document.getElementById('mostrarDiv8').addEventListener('click', function() {
    let minhaDiv = document.getElementById('minhaDiv18');

    if (minhaDiv.style.display === 'none') {
        minhaDiv.style.display = 'block';
    } 
    else {
        minhaDiv.style.display = 'none';
    }
    });
document.getElementById('mostrarDiv9').addEventListener('click', function() {
    let minhaDiv = document.getElementById('minhaDiv19');

    if (minhaDiv.style.display === 'none') {
        minhaDiv.style.display = 'block';
    } 
    else {
        minhaDiv.style.display = 'none';
    }
});
document.getElementById('mostrarDiv10').addEventListener('click', function() {
    let minhaDiv = document.getElementById('minhaDiv20');

    if (minhaDiv.style.display === 'none') {
        minhaDiv.style.display = 'block';
    } 
    else {
        minhaDiv.style.display = 'none';
    }
});